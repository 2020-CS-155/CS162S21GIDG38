/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cva_project;

import javax.swing.JOptionPane;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author QAMAR MEHAR
 */
                                   
public class CVA_Project {
  
    
                                       //Validators
    
    //Name Validator

    static boolean valid_StudentName(String name)
    {
        boolean flag = false ;
        int size = name.length();
        
        for(int i=0 ; i<size ; i++)
        {
            
            if((name.charAt(i) >= 'a' && name.charAt(i) <= 'z') || (name.charAt(i) >= 'A' && name.charAt(i) <= 'Z'))
            {
                flag = true ;
            }
            else
            {
                flag = false ;
            }
        }
        
        return flag ;
    }
    
                   //Addresss Validator
    static boolean valid_Address(String address)
    {
        boolean flag = false ;
        int size = address.length();
        
        for(int i=0 ; i<size ; i++)
        {
            
            if((address.charAt(i) >= 'a' && address.charAt(i) <= 'z') || (address.charAt(i) >= 'A' && address.charAt(i) <= 'Z'))
            {
                flag = true ;
            }
            else
            {
                flag = false ;
            }
        }
        
        return flag ;
    }
                   
                   //Password Validator
    static boolean valid_Password(String pass)
    {
        boolean flag = false ;
        int size = pass.length();
        
       if (size == 8 )
       {
        for(int i=0 ; i<size ; i++)
        {
            
            if((pass.charAt(0) >= 'a' && pass.charAt(3) <= 'z') && (pass.charAt(4) >= '0' && pass.charAt(7) <= '9'))
            {
                flag = true ;
            }
            else
            {
                flag = false ;
            }
        }
        }
       else
       {
           JOptionPane.showMessageDialog(null , "Password must contain 8 digits 1st 4 are letters and last 4 are integers...!!");
       }
        return flag ;
       
    }
    
                       //ID Validaor
    static boolean valid_Id_No(String id)
    {
        boolean flag = false ;
        int size = id.length();
        
       if (size == 3 )
       {
        for(int i=0 ; i<size ; i++)
        {
            
            if((id.charAt(0) >= 'A' && id.charAt(0) <= 'Z') && (id.charAt(1) >= '0' && id.charAt(2) <= '9'))
            {
                flag = true ;
            }
            else
            {
                flag = false ;
            }
        }
        }
       else
       {
           JOptionPane.showMessageDialog(null , "ID No  must contain 3 digits 1st one must capital letter and last 2 are integers...!!");
       }
        return flag ;
       
    }
            
                       //Valid Cnic
    static boolean valid_cnic(String cnic)
    {
        boolean flag = false ;
        int size = cnic.length();
        
       if (size == 15 )
       {
        for(int i=0 ; i<size ; i++)
        {
            
            if((cnic.charAt(0) >= '1' && cnic.charAt(4) <= '9' ) &&(cnic.charAt(5) == '-') &&(cnic.charAt(6) >= '1' && 
                    cnic.charAt(12) <= '9') && (cnic.charAt(13) == '-') && (cnic.charAt(14) >= '1' && cnic.charAt(14) <= '9'))
            {
                flag = true ;
            }
            else
            {
                flag = false ;
            }
        }
        }
       else
       {
           JOptionPane.showMessageDialog(null , "Cnic must contain 15 digits and according to Pak real id card No...!!");
       }
        return flag ;
       
    }
    
                       //Valid Phone no
    static boolean valid_Phone(String phone)
    {
        boolean flag = false ;
        int size = phone.length();
        
       if (size == 11  )
       {
        for(int i=0 ; i<size ; i++)
        {
            
            if( (phone.charAt(0) == '0' && phone.charAt(1) == '3') && (phone.charAt(2) >= '0' && phone.charAt(10) <= '9') )
            {
                flag = true ;
            }
            else
            {
                flag = false ;
            }
        }
        }
       else
       {
           JOptionPane.showMessageDialog(null , "Phone no must contain 11 digits and According to Pakistan Phone no...!!");
       }
        return flag ;
       
    }
    
                        //E-mail Validator
    public static boolean valid_Email(String email)
    {
        
        
        String passRegx = "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$";
        Pattern pattern = Pattern.compile(passRegx , Pattern.CASE_INSENSITIVE);
        Matcher matcher  = pattern.matcher(email);
        
        return matcher.find();
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Welcome wl = new Welcome();
        wl.setVisible(true);
        //NewJFrame nw = new NewJFrame();
        //nw.setVisible(true);
        //new_Admin ad = new new_Admin();
        //ad.setVisible(true);
    }
    
}
