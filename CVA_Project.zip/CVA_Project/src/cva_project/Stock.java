/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cva_project;

/**
 *
 * @author QAMAR MEHAR
 */
public class Stock {
    
    private String doze ;
    private String country ;
    private String company ;
    private String date ;

    public void setDoze(String doze) {
        this.doze = doze;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDoze() {
        return doze;
    }

    public String getCountry() {
        return country;
    }

    public String getCompany() {
        return company;
    }

    public String getDate() {
        return date;
    }
    
    
}
